# mc config

- contents of `~/.config/mc`
- created by `pjc-install.github.io`

